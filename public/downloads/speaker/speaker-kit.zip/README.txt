BRUNO CAPUANO SPEAKER KIT

This organizer kit contains three authentic event photographs and six biography drafts.
The biographies are pending owner editorial approval. Confirm the wording before use.

Public profile: https://elbruno.com/speaking/
LinkedIn: https://www.linkedin.com/in/elbruno/
GitHub: https://github.com/elbruno
Blog: https://elbruno.com
Podcast: https://notienenombre.com

The photo files are high-quality JPEG copies with location metadata removed.
They have not been generatively edited. The original source photographs remain unchanged.
This download does not grant image reuse rights. Confirm permission and required credit
with Bruno before publishing or redistributing any photograph.

The ZIP contains only the three official photos, bios-en.txt, bios-es.txt and this file.
